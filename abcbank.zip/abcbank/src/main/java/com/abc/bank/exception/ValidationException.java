package com.abc.bank.exception;

public class ValidationException extends Exception
{
    public ValidationException(String message)
    {
        super(message);
    }
}
