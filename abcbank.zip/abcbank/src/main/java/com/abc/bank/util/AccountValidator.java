package com.abc.bank.util;

import com.abc.bank.exception.ValidationException;
import com.abc.bank.modal.Account;

public class AccountValidator
{
    public static void studentValidator(Account account ) throws ValidationException
    {
        if(account.getAccountNo() == null )
        {
            throw new ValidationException("Account Number is not specified");
        } else if ( account.getAccountType().isBlank())
        {
            throw new ValidationException("Account Type is not specified");
        } else if ( account.getLastTransactionDate() == null )
        {
            throw new ValidationException("Transaction Date is not specified");
        } 
    }
}
