package com.abc.bank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.abc.bank.exception.ValidationException;
import com.abc.bank.modal.Account;
import com.abc.bank.service.AccountSummaryService;

@RestController
public class AccountSummaryController {
    @Autowired
    AccountSummaryService accountSummaryService;

   
    @GetMapping("/accounts/{customerId}")
    public List<Account> getAllAccounts(@PathVariable("customerId") Long customerId) throws ValidationException
    {
    
		return accountSummaryService.getAllAccounts(customerId);
    }

   
}
