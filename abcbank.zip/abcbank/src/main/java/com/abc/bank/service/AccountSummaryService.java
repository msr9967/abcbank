package com.abc.bank.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.abc.bank.exception.ValidationException;
import com.abc.bank.modal.Account;
import com.abc.bank.repository.AccountSummaryRepository;

@Service
public class AccountSummaryService {
	@Autowired
	AccountSummaryRepository accountSummaryRepository;

	public List<Account> getAllAccounts(long customerId) throws ValidationException {
		List<Account> account = accountSummaryRepository.findByCustId(customerId);
		if (account.size() <=0) {
			throw new ValidationException("Customer with id  does not exists");
		} else {
			return account;
		}
	}

}
