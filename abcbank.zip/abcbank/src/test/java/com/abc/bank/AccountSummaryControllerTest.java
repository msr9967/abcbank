package com.abc.bank;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.abc.bank.modal.Account;
import com.abc.bank.service.AccountSummaryService;

@WebMvcTest
public class AccountSummaryControllerTest {
	@Autowired
    private MockMvc mockMvc;

    @MockBean
    private AccountSummaryService accountSummaryService;
    @Test
    public void getAllAccounts() throws Exception{
    	Account account = new Account();
    	account.setCustomerId(1);
    	accountSummaryService.getAllAccounts(account.getCustomerId());
    	
    }
    }

