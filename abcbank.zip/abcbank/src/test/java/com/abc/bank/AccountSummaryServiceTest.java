package com.abc.bank;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.abc.bank.modal.Account;
import com.abc.bank.repository.AccountSummaryRepository;
import com.abc.bank.service.AccountSummaryService;

@ExtendWith(MockitoExtension.class)
public class AccountSummaryServiceTest {
	@Mock
    private AccountSummaryRepository accountSummaryRepository;

    @InjectMocks
    private AccountSummaryService accountSummaryService;
    @Test
    public void getAllAccounts() throws Exception{
    	Account account = new Account();
    	account.setCustomerId(1);
    	accountSummaryRepository.findByCustId(account.getCustomerId());
    	
    }
}
